package main

import (
	"github.com/mengelbart/rtp-over-quic/cmd"
)

func main() {
	cmd.Execute()
}
